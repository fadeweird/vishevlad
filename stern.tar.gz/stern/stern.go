package stern

import (
	"bytes"
	"crypto/aes"
	"crypto/cipher"
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha3"
	"encoding/base64"
	"encoding/binary"
	"fmt"
	"hash"
	"io"
	"log"
	"strings"

	"golang.org/x/crypto/hkdf"
)

const (
	ChunkSize      = 31 * 1024
	StreamKeySize  = 32
	NonceSize      = 12
	Overhead       = 16
	MACKeySize     = 32
	StreamWordSize = 64
	NonceAddSize   = 2
)

const (
	ArgonTimeFactor   uint32 = 1
	ArgonMemoryFactor uint32 = 1024 * 1024
	ArgonCPUFactor    uint8  = 8
)

const (
	HeaderPrefix     = "stern-v0"
	EncapPrefix      = "---> "
	StreamWordPrefix = "-/-> "
	MetadataPrefix   = "-:-> "
	MACPrefix        = "+--> "
)

var DefaultMetadata = []byte("stern default metadata")

var b64 = base64.RawStdEncoding.Strict()

type Encryptor struct {
	src                 io.Reader
	aead                cipher.AEAD
	buf, chunk          []byte
	nonce               []byte
	pubkey              *PubKey
	header              *bytes.Buffer
	sended, recv        int
	sendChunk           bool
	lastChunk           bool
	firstChunkEncrypted bool
	headerCreated       bool
	headerSended        bool
	shake               *sha3.SHAKE
	add                 []byte
	metadata            []byte
	maskHeader          bool
}

func NewEncryptor(pubkey *PubKey, src io.Reader) (e *Encryptor) {
	e = new(Encryptor)
	e.pubkey = pubkey
	e.src = src
	e.buf = make([]byte, ChunkSize)
	e.chunk = make([]byte, ChunkSize+Overhead)
	e.nonce = make([]byte, NonceSize)
	e.add = make([]byte, NonceAddSize)
	e.metadata = DefaultMetadata
	return
}

func (e *Encryptor) WithMetadata(metadata []byte) {
	if len(metadata) > (MaxReadLineBuf - Overhead - len(MetadataPrefix)) {
		panic("metadata too large")
	}
	e.metadata = metadata
	return
}

func (e *Encryptor) WithMaskedHeader() {
	e.maskHeader = true
}

func (e *Encryptor) createHeader() {
	e.header = &bytes.Buffer{}
	headerLine := ""
	headerLine += HeaderPrefix + "\n"

	streamWord := extractSecret(rand.Reader, StreamWordSize)
	shared, encap := e.pubkey.Encap()
	headerLine += EncapPrefix + b64.EncodeToString(encap) + "\n"

	hk := hkdf.New(
		func() hash.Hash { return sha3.New512() },
		shared,
		encap,
		[]byte("stern-extract-secrets-for-stream-word"))

	streamWordEnc := EncryptOnce(
		extractSecret(hk, StreamKeySize),
		streamWord,
		[]byte("stern-stream-word"))

	hk = hkdf.New(
		func() hash.Hash { return sha3.New512() },
		streamWord,
		createSalt(shared, encap, streamWordEnc),
		[]byte("stern-extract-secrets"))

	headerLine += StreamWordPrefix +
		b64.EncodeToString(streamWordEnc) + "\n"

	streamKey := extractSecret(hk, StreamKeySize)
	e.aead = createAEAD(streamKey)
	e.nonce = extractSecret(hk, NonceSize)

	metadataEnc := e.aead.Seal(
		nil, e.nonce,
		e.metadata, []byte("stern-metadata"))

	headerLine += MetadataPrefix +
		b64.EncodeToString(metadataEnc) + "\n"

	hmacKey := extractSecret(hk, MACKeySize)

	h := hmac.New(func() hash.Hash {
		return sha3.New512()
	}, hmacKey)

	forHmac := make([]byte, 0)
	forHmac = append(forHmac, encap...)
	forHmac = append(forHmac, metadataEnc...)
	forHmac = append(forHmac, streamWordEnc...)
	_, err := h.Write(forHmac)
	if err != nil {
		panic(err)
	}

	mac := h.Sum(nil)
	headerLine += MACPrefix +
		b64.EncodeToString(mac) + "\n"
	e.header.WriteString(headerLine)

	if e.maskHeader {
		e.maskHeaderFunc(shared, encap)
	}

	e.shake = sha3.NewSHAKE256()
	if _, err := e.shake.Write(extractSecret(hk, NonceSize)); err != nil {
		panic(err)
	}
	e.incrNonce()
	e.headerCreated = true
}

func (e *Encryptor) maskHeaderFunc(shared, encap []byte) {
	size := make([]byte, 4+Overhead)
	maskedHeader := make([]byte, e.header.Len()+Overhead)
	binary.PutVarint(size[:4], int64(len(maskedHeader)))
	io.ReadFull(e.header, maskedHeader)
	hk2 := hkdf.New(
		func() hash.Hash { return sha3.New512() },
		shared,
		encap,
		[]byte("stern-extract-for-mask-header"))
	aead := createAEAD(extractSecret(hk2, StreamKeySize))
	nonce1 := extractSecret(hk2, NonceSize)
	aead.Seal(size[:0], nonce1, size[:4], []byte("stern-masked-header-size"))
	e.header.Write(encap)
	e.header.Write(size)

	nonce2 := extractSecret(hk2, NonceSize)
	aead.Seal(maskedHeader[:0], nonce2, maskedHeader[:len(maskedHeader)-Overhead], []byte("stern-masked-header"))
	e.header.Write(maskedHeader)
}

func (e *Encryptor) Read(p []byte) (n int, err error) {
	if !e.headerCreated {
		e.createHeader()
	}
	if !e.headerSended && e.firstChunkEncrypted {
		n, err = e.header.Read(p)
		if err != nil && err != io.EOF {
			panic(err)
		}

		if err == io.EOF {
			err = nil
			e.headerSended = true
		}
		return
	}

	if e.sendChunk {
		n = copy(p, e.chunk[e.sended:e.recv+Overhead])
		e.sended += n
		if e.sended == e.recv+Overhead {
			e.sendChunk = false
			e.sended = 0
			e.recv = 0
			if e.lastChunk {
				err = io.EOF
			}
		}
		return
	}

	c, err := e.src.Read(e.buf[e.recv:])
	if err != nil && err != io.EOF {
		panic(err)
	}

	e.recv += c

	if err == io.EOF {
		e.lastChunk = true
	}

	if e.recv == len(e.buf) || e.lastChunk && (e.recv != 0 || !e.headerSended) {
		if !e.lastChunk {
			e.aead.Seal(e.chunk[:0], e.nonce, e.buf[:e.recv], []byte("stern-chunk"))
			e.incrNonce()
		} else {
			e.aead.Seal(e.chunk[:0], e.nonce, e.buf[:e.recv], []byte("stern-last-chunk"))
		}
		e.sendChunk = true
		if !e.headerSended {
			e.firstChunkEncrypted = true
		}

		err = nil
	}
	return
}

func logSetFlags() {
	log.SetFlags(0)
}

type DecryptorGeneric struct {
	src          io.Reader
	aead         cipher.AEAD
	buf, chunk   []byte
	nonce        []byte
	sended, recv int
	sendChunk    bool
	lastChunk    bool
	headerParsed bool
	decapFunc    DecapFunc
	sec          *SecKey
	metadata     []byte
	shake        *sha3.SHAKE
	add          []byte
	headerBuf    *bytes.Buffer
	decapDone    bool
	shared       []byte
}

type DecapFunc func(encap []byte) (shared []byte, err error)

func NewDecryptor(sec *SecKey, src io.Reader) (d *DecryptorGeneric) {
	d = NewDecryptorGeneric(nil, sec, src)
	return
}

func NewDecryptorGeneric(decapFunc DecapFunc, sec *SecKey, src io.Reader) (d *DecryptorGeneric) {
	d = new(DecryptorGeneric)
	d.src = src
	d.buf = make([]byte, ChunkSize+Overhead)
	d.chunk = make([]byte, ChunkSize)
	d.nonce = make([]byte, NonceSize)
	d.add = make([]byte, NonceAddSize)
	d.decapFunc = decapFunc
	d.headerBuf = &bytes.Buffer{}
	d.sec = sec
	return
}

func (d *DecryptorGeneric) unmaskHeader() {
	for d.headerBuf.Len() < CiphertextSize+4+Overhead {
		c, err := d.src.Read(d.buf[:1024])
		if err != nil {
			panic("masked header invalid")
		}
		d.headerBuf.Write(d.buf[:c])
	}

	encap := make([]byte, CiphertextSize)
	io.ReadFull(d.headerBuf, encap)

	var err error

	if d.sec != nil {
		d.shared = d.sec.Decap(encap)
	} else {
		d.shared, err = d.decapFunc(encap)
		if err != nil {
			panic(err)
		}
	}
	d.decapDone = true

	size := make([]byte, 4+Overhead)
	io.ReadFull(d.headerBuf, size)

	hk2 := hkdf.New(
		func() hash.Hash { return sha3.New512() },
		d.shared,
		encap,
		[]byte("stern-extract-for-mask-header"))

	aead := createAEAD(extractSecret(hk2, StreamKeySize))
	nonce1 := extractSecret(hk2, NonceSize)
	_, err = aead.Open(size[:0], nonce1, size, []byte("stern-masked-header-size"))
	if err != nil {
		panic(err)
	}

	s, bs := binary.Varint(size)
	if bs > 2 {
		panic("too large masked header size")
	}

	maskedHeader := make([]byte, s)

	for d.headerBuf.Len() < int(s) {
		c, err := d.src.Read(d.buf[:1024])
		if err != nil {
			panic("masked header invalid")
		}
		d.headerBuf.Write(d.buf[:c])
	}
	io.ReadFull(d.headerBuf, maskedHeader)
	if d.headerBuf.Len() != 0 {
		c, err := io.ReadFull(d.headerBuf, d.buf[:d.headerBuf.Len()])
		if err != nil {
			panic(err)
		}
		d.recv = c
	}

	nonce2 := extractSecret(hk2, NonceSize)
	_, err = aead.Open(maskedHeader[:0], nonce2, maskedHeader, []byte("stern-masked-header"))
	if err != nil {
		panic(err)
	}
	d.headerBuf.Write(maskedHeader[:len(maskedHeader)-Overhead])
}

func (d *DecryptorGeneric) parseHeader() {
	for d.headerBuf.Len() < len([]byte(HeaderPrefix+"\n")) {
		c, err := d.src.Read(d.buf[:1])
		if err != nil {
			panic(err)
		}
		d.headerBuf.Write(d.buf[:c])
	}

	headerReader := d.src
	if strings.TrimSpace(d.headerBuf.String()) != HeaderPrefix {
		d.unmaskHeader()
		headerReader = d.headerBuf
		if readLine(headerReader, '\n') != HeaderPrefix {
			panic("unmasked header invalid")
		}
	}

	encapRaw := readLine(headerReader, '\n')
	encap, err := b64.DecodeString(encapRaw[len(EncapPrefix):])
	if err != nil {
		panic(err)
	}

	if !d.decapDone {
		if d.sec != nil {
			d.shared = d.sec.Decap(encap)
		} else {
			d.shared, err = d.decapFunc(encap)
			if err != nil {
				panic(err)
			}
		}
	}

	streamWordRaw := readLine(headerReader, '\n')
	streamWordEnc, err := b64.DecodeString(
		streamWordRaw[len(StreamWordPrefix):])
	if err != nil {
		panic(err)
	}

	hk := hkdf.New(
		func() hash.Hash { return sha3.New512() },
		d.shared,
		encap,
		[]byte("stern-extract-secrets-for-stream-word"))

	streamWord := DecryptOnce(
		extractSecret(hk, StreamKeySize),
		streamWordEnc,
		[]byte("stern-stream-word"))

	hk = hkdf.New(
		func() hash.Hash { return sha3.New512() },
		streamWord,
		createSalt(d.shared, encap, streamWordEnc),
		[]byte("stern-extract-secrets"))

	streamKey := extractSecret(hk, StreamKeySize)
	d.aead = createAEAD(streamKey)
	d.nonce = extractSecret(hk, NonceSize)

	metadataRaw := readLine(headerReader, '\n')
	metadataEnc, err := b64.DecodeString(metadataRaw[len(MetadataPrefix):])
	if err != nil {
		panic(err)
	}

	hmacKey := extractSecret(hk, MACKeySize)
	h := hmac.New(defaultHashFunc, hmacKey)
	forHmac := make([]byte, 0)
	forHmac = append(forHmac, encap...)
	forHmac = append(forHmac, metadataEnc...)
	forHmac = append(forHmac, streamWordEnc...)
	if _, err := h.Write(forHmac); err != nil {
		panic(err)
	}
	mac := h.Sum(nil)
	macRaw := readLine(headerReader, '\n')
	headerMac, err := b64.DecodeString(macRaw[len(MACPrefix):])
	if err != nil {
		panic(err)
	}
	if !hmac.Equal(headerMac, mac) {
		panic("MAC invalid")
	}

	d.metadata, err = d.aead.Open(nil, d.nonce, metadataEnc, []byte("stern-metadata"))
	if err != nil {
		panic(fmt.Errorf("metadata decryption failed: %v", err))
	}

	d.shake = sha3.NewSHAKE256()
	if _, err := d.shake.Write(extractSecret(hk, NonceSize)); err != nil {
		panic(err)
	}

	d.incrNonce()
	d.headerParsed = true
}

func (d *DecryptorGeneric) GetMetadata() []byte {
	if !d.headerParsed {
		d.parseHeader()
	}
	return d.metadata
}

func (d *DecryptorGeneric) Read(p []byte) (n int, err error) {
	if !d.headerParsed {
		d.parseHeader()
	}

	if d.sendChunk {
		n = copy(p, d.chunk[d.sended:d.recv-Overhead])
		d.sended += n
		if d.sended == d.recv-Overhead {
			d.sendChunk = false
			d.sended = 0
			d.recv = 0
			if d.lastChunk {
				err = io.EOF
			}
		}
		return
	}

	c, err := d.src.Read(d.buf[d.recv:])
	if err != nil && err != io.EOF {
		panic(err)
	}
	d.recv += c

	if err == io.EOF {
		d.lastChunk = true
	}

	if (d.recv == len(d.buf) || d.lastChunk) && d.recv != 0 {
		var decryptErr error
		if !d.lastChunk {
			_, decryptErr = d.aead.Open(d.chunk[:0], d.nonce, d.buf[:d.recv], []byte("stern-chunk"))
			d.incrNonce()
		} else {
			_, decryptErr = d.aead.Open(d.chunk[:0], d.nonce, d.buf[:d.recv], []byte("stern-last-chunk"))

		}
		if decryptErr != nil {
			panic(decryptErr)
		}
		d.sendChunk = true
		err = nil
	}
	return
}

func (e *Encryptor) incrNonce() {
	incrNonce(e.nonce, e.add, e.shake)
}

func (d *DecryptorGeneric) incrNonce() {
	incrNonce(d.nonce, d.add, d.shake)
}

func createAEAD(key []byte) cipher.AEAD {
	aead := createAES256AEAD(key)
	return aead
}

func createAES256AEAD(key []byte) cipher.AEAD {
	block, err := aes.NewCipher(key)
	if err != nil {
		panic(err)
	}

	aead, err := cipher.NewGCM(block)
	if err != nil {
		panic(err)
	}
	return aead
}

func incrNonce(nonce, add []byte, rand io.Reader) {
	for i := NonceSize - NonceAddSize - 1; i >= 0; i-- {
		if _, err := io.ReadFull(rand, add); err != nil {
			panic(err)
		}
		copy(nonce[NonceSize-len(add):], add)

		nonce[i]++
		if nonce[i] != 0 {
			return
		}
	}
	panic("nonce is wrapped")
}
