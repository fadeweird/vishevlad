module stern

go 1.26.0

require (
	github.com/cosmos/btcutil v1.0.5
	github.com/ericlagergren/aegis v0.0.0-20250325060835-cd0defd64358
	github.com/gookit/color v1.6.0
	golang.org/x/crypto v0.49.0
	golang.org/x/sys v0.42.0
	golang.org/x/term v0.41.0
)

require (
	github.com/companyzero/sntrup4591761 v0.0.0-20220309191932-9e0f3af2f07a // indirect
	github.com/ericlagergren/subtle v0.0.0-20220507045147-890d697da010 // indirect
	github.com/xo/terminfo v0.0.0-20220910002029-abceb7e1c41e // indirect
)
