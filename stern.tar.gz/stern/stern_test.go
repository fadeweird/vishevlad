package stern

import (
	"bytes"
	"crypto/rand"
	"crypto/sha3"
	"io"
	mathrand "math/rand/v2"
	"os"
	"slices"
	"strings"

	"testing"
)

var (
	drand    = createDefaultRand()
	testData = []byte("test-data")
)

func createDefaultRand() io.Reader {
	r := sha3.NewSHAKE256()
	r.Write([]byte("stern-default-rand"))
	return r
}

func TestEncryptDecrypt(t *testing.T) {
	maxSize := 1 << 18
	sizes := []int{0, 1, 2, 3, 5, 7, 11, 12, 16, 64, 12461, ChunkSize, ChunkSize - 1, ChunkSize + 1, ChunkSize * 7, 2821, 4677, 26631, 246, 11111, 1719817}

	if maxSize < slices.Max(sizes) {
		maxSize = slices.Max(sizes)
	}
	plain := make([]byte, maxSize)
	size := int(mathrand.IntN(maxSize))
	plain = plain[:size]
	_, err := io.ReadFull(rand.Reader, plain[:size])
	if err != nil {
		panic(err)
	}

	pubkey, seckey := GenerateKeys(rand.Reader)
	if !encryptDecrypt(pubkey, seckey, bytes.NewReader(plain)) {
		t.Error("plaintext != decrypted")
	}
	if !encryptDecryptWithMasked(pubkey, seckey) {
		t.Error("plaintext != decrypted")
	}

	for i := 0; i < 25; i++ {
		sizes = append(sizes, int(mathrand.IntN(maxSize)))
	}

	for _, size := range sizes {
		plain = plain[:size]
		_, err := io.ReadFull(rand.Reader, plain)
		if err != nil {
			panic(err)
		}
		if !encryptDecrypt(pubkey, seckey, bytes.NewReader(plain)) {
			t.Error("plaintext != decrypted")
		}
	}
}

func encryptDecrypt(pubkey *PubKey, seckey *SecKey, src io.Reader) bool {
	buf := &bytes.Buffer{}
	buf2 := &bytes.Buffer{}
	buf3 := &bytes.Buffer{}
	if _, err := io.Copy(buf, src); err != nil {
		panic(err)
	}

	e := NewEncryptor(pubkey, bytes.NewReader(buf.Bytes()))
	d := NewDecryptor(seckey, e)

	if _, err := io.Copy(buf2, d); err != nil {
		panic(err)
	}

	if !bytes.Equal(buf.Bytes(), buf2.Bytes()) {
		return false
	}

	buf2.Reset()
	e = NewEncryptor(pubkey, bytes.NewReader(buf.Bytes()))
	b := make([]byte, 1)
	io.CopyBuffer(buf2, e, b)
	d = NewDecryptor(seckey, buf2)
	io.CopyBuffer(buf3, d, b)
	return bytes.Equal(buf.Bytes(), buf3.Bytes())
}

func encryptDecryptWithMasked(pubkey *PubKey, seckey *SecKey) bool {
	buf := &bytes.Buffer{}
	buf2 := &bytes.Buffer{}
	if _, err := io.CopyN(buf, rand.Reader, 1<<27); err != nil {
		panic(err)
	}

	e := NewEncryptor(pubkey, bytes.NewReader(buf.Bytes()))
	e.WithMaskedHeader()
	d := NewDecryptor(seckey, e)
	if _, err := io.Copy(buf2, d); err != nil {
		panic(err)
	}
	return bytes.Equal(buf.Bytes(), buf2.Bytes())
}

func TestEncryptDecryptFileSafeMode(t *testing.T) {
	f1, err := os.CreateTemp(os.Getenv("TMPDIR"), "stern")
	if err != nil {
		panic(err)
	}
	defer os.Remove(f1.Name())

	pubkey, seckey := GenerateKeys(rand.Reader)
	_, err = io.CopyN(f1, rand.Reader, 1<<25)
	if err != nil {
		panic(err)
	}
	f1, err = os.Open(f1.Name())
	if err != nil {
		panic(err)
	}

	e := NewEncryptor(pubkey, f1)
	f2, err := os.CreateTemp(os.Getenv("TMPDIR"), "stern")
	if err != nil {
		panic(err)
	}
	defer os.Remove(f2.Name())

	f3, err := os.CreateTemp(os.Getenv("TMPDIR"), "stern")
	if err != nil {
		panic(err)
	}
	defer os.Remove(f3.Name())

	if err := SafeCopyToFileFast(f2.Name(), e); err != nil {
		t.Error(err)
	}

	f1, err = os.Open(f1.Name())
	if err != nil {
		panic(err)
	}
	e = NewEncryptor(pubkey, f1)
	if err := SafeCopyToFile(f3.Name(), e); err != nil {
		t.Error(err)
	}

	f2, err = os.Open(f2.Name())
	if err != nil {
		panic(err)
	}
	d := NewDecryptor(seckey, f2)

	devnull, err := os.Create("/dev/null")
	if err != nil {
		panic(err)
	}
	if _, err := io.Copy(devnull, d); err != nil {
		panic(err)
	}

	f3, err = os.Open(f3.Name())
	if err != nil {
		panic(err)
	}

	d = NewDecryptor(seckey, f3)
	if _, err := io.Copy(devnull, d); err != nil {
		panic(err)
	}
}

func TestEncryptDecryptFile(t *testing.T) {
	f1, err := os.CreateTemp(os.Getenv("TMPDIR"), "stern")
	if err != nil {
		panic(err)
	}
	defer os.Remove(f1.Name())

	f2, err := os.CreateTemp(os.Getenv("TMPDIR"), "stern")
	if err != nil {
		panic(err)
	}
	defer os.Remove(f2.Name())

	f3, err := os.CreateTemp(os.Getenv("TMPDIR"), "stern")
	if err != nil {
		panic(err)
	}
	defer os.Remove(f3.Name())

	if _, err := io.CopyN(f1, rand.Reader, 1<<25); err != nil {
		panic(err)
	}

	f1, err = os.Open(f1.Name())
	if err != nil {
		panic(err)
	}

	pubkey, seckey := GenerateKeys(rand.Reader)
	e := NewEncryptor(pubkey, f1)
	_, err = io.Copy(f2, e)
	if err != nil {
		panic(err)
	}

	f2, err = os.Open(f2.Name())
	if err != nil {
		panic(err)
	}

	d := NewDecryptor(seckey, f2)
	if _, err = io.Copy(f3, d); err != nil {
		panic(err)
	}

	if !filesEqual(f1.Name(), f3.Name()) {
		t.Error("files not equal")
	}
}

func TestBadMAC(t *testing.T) {
	buf := &bytes.Buffer{}
	pk, sk := GenerateKeys(drand)
	e := NewEncryptor(pk, bytes.NewReader(testData))
	io.Copy(buf, e)
	res := buf.String()
	headerWithNoMAC := strings.Join(strings.Split(res, "\n")[:4], "\n")
	headerBadMAC := headerWithNoMAC + "\n+--> Rw+UZ+Aj+jtCNdsJ4Of8URbMVQmbAFDki4DIAcci/b6oherh4PI7XSLpDFOPUawQ560MyLHLbjHrrTjImeF1Gw"
	d := NewDecryptor(sk, bytes.NewReader([]byte(headerBadMAC)))
	assertPanicsWith(t, "MAC invalid", func() {
		tmp := &bytes.Buffer{}
		io.Copy(tmp, d)
	})
}

func TestBadMetadata(t *testing.T) {
	buf := &bytes.Buffer{}
	pk, sk := GenerateKeys(drand)
	e := NewEncryptor(pk, bytes.NewReader(testData))
	io.Copy(buf, e)
	res := buf.String()
	raw := make([]string, 0)
	raw = append(raw, strings.Split(res, "\n")[:3]...)
	raw = append(raw, "-:-> hcoHXwKDzcLR42eM5iM5bhnDH79osjoWRuTZZKiXqGv8GEgXHv0")
	raw = append(raw, strings.Split(res, "\n")[4:5]...)
	badHeader := strings.Join(raw, "\n")
	d := NewDecryptor(sk, bytes.NewReader([]byte(badHeader)))

	assertPanicsWith(t, "MAC invalid", func() {
		tmp := &bytes.Buffer{}
		io.Copy(tmp, d)
	})
}

func TestBadHeader(t *testing.T) {
	buf := &bytes.Buffer{}
	pk, sk := GenerateKeys(drand)
	e := NewEncryptor(pk, bytes.NewReader(testData))
	io.Copy(buf, e)
	badHeader := "stern-v0\n---> GoiJSt+vN+IQmx/D74cURqdIjgLOOjVxiy82fhPf7Z2VyFHs1CwURjfkgbw+F4OkbZqdRi/Vnc7UP8eYW+1r6Q"
	d := NewDecryptor(sk, bytes.NewReader([]byte(badHeader)))

	assertPanicsWith(t, "ciphertext invalid", func() {
		tmp := &bytes.Buffer{}
		io.Copy(tmp, d)
	})
}

type ZerosReader struct {
	buf []byte
}

func newZerosReader() *ZerosReader {
	z := new(ZerosReader)
	z.buf = make([]byte, 32*1024)
	return z
}

func (z *ZerosReader) Read(p []byte) (n int, err error) {
	n = copy(p, z.buf)
	return n, nil
}

func BenchmarkEncrypt256M(b *testing.B) {
	pk, _ := GenerateKeys(drand)
	z := newZerosReader()
	out, _ := os.Create("/dev/null")
	b.Run("", func(b *testing.B) {
		for i := 0; i < b.N; i++ {
			e := NewEncryptor(pk, io.LimitReader(z, 256*1024*1024))
			io.Copy(out, e)
		}
	})
}

func BenchmarkDecrypt256M(b *testing.B) {
	pk, sk := GenerateKeys(drand)
	z := newZerosReader()
	out, _ := os.Create("/dev/null")
	e := NewEncryptor(pk, io.LimitReader(z, 256*1024*1024))
	buf := &bytes.Buffer{}
	io.Copy(buf, e)
	tmp := buf.Bytes()
	buf.Reset()
	b.Run("", func(b *testing.B) {
		for i := 0; i < b.N; i++ {
			r := bytes.NewReader(tmp)
			d := NewDecryptor(sk, r)
			io.Copy(out, d)
		}
	})
}

func filesEqual(f1name, f2name string) bool {
	f1, err := os.Open(f1name)
	if err != nil {
		panic(err)
	}
	defer f1.Close()

	f2, err := os.Open(f2name)
	if err != nil {
		panic(err)
	}
	defer f2.Close()

	b1, b2 := make([]byte, 31*1024), make([]byte, 31*1024)
	for {
		c1, err1 := f1.Read(b1)
		c2, err2 := f2.Read(b2)
		if err1 != err2 {
			panic(err1)
		}

		if !bytes.Equal(b1[:c1], b2[:c2]) {
			return false
		}

		if err1 == io.EOF {
			break
		}

	}
	return true
}

func assertPanicsWith(t *testing.T, expected any, f func()) {
	t.Helper()
	defer func() {
		r := recover()
		if r == nil {
			t.Error("ожидалась паника")
			return
		}
		if r != expected {
			t.Errorf("неверное значение паники:\nполучили: %v\nожидали: %v", r, expected)
		}
	}()
	f()
}

type testReader struct {
	max, sended int
	counter     int
	buf         []byte
	done        bool
	fillChunk   bool
}

func newTestReader(max int) (s *testReader) {
	s = new(testReader)
	s.max = max
	s.done = false
	return
}

func (s *testReader) Reset() {
	s.done = false
	s.sended = 0
	s.counter = 0
}

func (s *testReader) Read(p []byte) (n int, err error) {
	if s.done {
		err = io.EOF
		return
	}

	x := 0
	if int(mathrand.Uint32())%10 < 5 {
		x = int(mathrand.Uint32()) % 10
	}

	if s.fillChunk {
		s.buf = make([]byte, x)
		for i := range s.buf {
			if s.counter == s.max {
				s.buf = s.buf[:i]
				s.fillChunk = false
				return 0, nil
			}
			s.counter++
			s.buf[i] = uint8(s.counter)
			if s.buf[i] == 0 {
				s.buf[i] = 1
			}
		}
		s.fillChunk = false
	}
	n = copy(p, s.buf[s.sended:])
	s.sended += n
	if s.sended == len(s.buf) {
		s.sended = 0
		s.fillChunk = true

		if s.counter == s.max {
			s.done = true
			err = io.EOF
		}
	}
	return
}
