package stern

import (
	"crypto/ecdh"
	"crypto/mlkem"
	"crypto/rand"
	"io"

	"golang.org/x/crypto/hkdf"
)

const (
	PubKeyPrefix   = "stern-public-key-"
	SecKeyPrefix   = "STERN-SECRET-KEY-"
	PubKeySize     = mlkem.EncapsulationKeySize1024 + X25519KeySize
	CiphertextSize = mlkem.CiphertextSize1024 + X25519KeySize + SaltSize
	SharedKeySize  = 64
	SubKeySize     = 64
	X25519KeySize  = 32
	SecKeySize     = mlkem.SeedSize + X25519KeySize + SubKeySize
	SaltSize       = 32
	SecKeyEncSize  = SecKeySize + Overhead + Overhead - SubKeySize
)

func GenerateKeys(r io.Reader) (pub *PubKey, sec *SecKey) {
	seed := make([]byte, SecKeySize)
	if _, err := io.ReadFull(r, seed); err != nil {
		panic(err)
	}

	sec = NewSecKey(seed)
	pub = sec.PubKey()
	return
}

func NewSecKey(seed []byte) (sec *SecKey) {
	if len(seed) != SecKeySize {
		panic("invalid seed length")
	}

	sec = new(SecKey)

	mlkemSeed := seed[:mlkem.SeedSize]
	mlkemKey, err := mlkem.NewDecapsulationKey1024(mlkemSeed)
	if err != nil {
		panic(err)
	}
	sec.mlkemKey = mlkemKey

	if err != nil {
		panic(err)
	}

	curve := ecdh.X25519()
	sec.x25519Key, err = curve.NewPrivateKey(seed[mlkem.SeedSize : mlkem.SeedSize+X25519KeySize])
	if err != nil {
		panic(err)
	}

	sec.subkey = seed[len(seed)-SubKeySize:]
	return
}

func NewPubKey(raw []byte) (pub *PubKey) {
	if len(raw) != PubKeySize {
		panic("invalid pubkey length")
	}

	pub = new(PubKey)
	pk, err := mlkem.NewEncapsulationKey1024(raw[:mlkem.EncapsulationKeySize1024])
	if err != nil {
		panic(err)
	}

	pub.mlkemKey = pk

	curve := ecdh.X25519()
	x25519, err := curve.NewPublicKey(raw[len(raw)-X25519KeySize:])
	if err != nil {
		panic(err)
	}

	pub.x25519Key = x25519
	return
}

type SecKey struct {
	mlkemKey  *mlkem.DecapsulationKey1024
	x25519Key *ecdh.PrivateKey
	subkey    []byte
}

func (sec *SecKey) SubKey() []byte {
	return sec.subkey
}

func (sec *SecKey) Bytes() []byte {
	result := make([]byte, 0, SecKeySize)
	result = append(result, sec.mlkemKey.Bytes()...)
	result = append(result, sec.x25519Key.Bytes()...)
	result = append(result, sec.subkey...)
	return result
}

func (sec *SecKey) PubKey() (pub *PubKey) {
	pub = new(PubKey)
	pub.mlkemKey = sec.mlkemKey.EncapsulationKey()
	pub.x25519Key = sec.x25519Key.PublicKey()
	return
}

func (sec *SecKey) Decap(encap []byte) (shared []byte) {
	if len(encap) != CiphertextSize {
		panic("ciphertext invalid")
	}
	mlkemShared, err := sec.mlkemKey.Decapsulate(encap[:mlkem.CiphertextSize1024])

	curve := ecdh.X25519()
	footprint, err := curve.NewPublicKey(encap[mlkem.CiphertextSize1024 : mlkem.CiphertextSize1024+X25519KeySize])
	if err != nil {
		panic(err)
	}

	x25519Shared, err := sec.x25519Key.ECDH(footprint)
	if err != nil {
		panic(err)
	}

	shared = createShared(
		mlkemShared,
		x25519Shared,
		encap,
		sec.PubKey().Bytes(),
	)
	return
}

func createShared(mlkemShared, x25519Shared, ciphertext, pubkey []byte) []byte {
	hk := hkdf.New(
		defaultHashFunc,
		append(mlkemShared, x25519Shared...),
		append(ciphertext, pubkey...),
		[]byte("stern-hybrid-shared-generation"),
	)
	return extractSecret(hk, SharedKeySize)
}

func ParseSecKey(r io.Reader) (sec *SecKey) {
	_, sec, _ = parseKeys(r, true, false)
	return
}

func ParsePubKey(r io.Reader) (pub *PubKey) {
	pub, _, _ = parseKeys(r, false, false)
	return
}

func ParseSubKey(r io.Reader) (sub []byte) {
	_, _, sub = parseKeys(r, false, true)
	return
}

type PubKey struct {
	mlkemKey  *mlkem.EncapsulationKey1024
	x25519Key *ecdh.PublicKey
}

func (pub *PubKey) Bytes() []byte {
	result := make([]byte, 0, PubKeySize)
	result = append(result, pub.mlkemKey.Bytes()...)
	result = append(result, pub.x25519Key.Bytes()...)
	return result
}

func (pub *PubKey) Encap() (shared, encap []byte) {
	mlkemShared, encap := pub.mlkemKey.Encapsulate()

	curve := ecdh.X25519()
	third, err := curve.GenerateKey(rand.Reader)
	if err != nil {
		panic(err)
	}

	footprint := third.PublicKey()

	x25519Shared, err := third.ECDH(pub.x25519Key)
	if err != nil {
		panic(err)
	}

	encap = append(encap, footprint.Bytes()...)
	salt := extractSecret(rand.Reader, SaltSize)
	encap = append(encap, salt...)
	shared = createShared(
		mlkemShared,
		x25519Shared,
		encap,
		pub.Bytes(),
	)
	return
}
