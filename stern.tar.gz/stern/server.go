package stern

import (
	"encoding/json"
	"errors"
	"net"
	"os"
	"path/filepath"
	"time"
)

const (
	socketName = "stern-secrets-server.socket"
)

var (
	confdir           = filepath.Join(os.Getenv("HOME"), ".config/stern")
	DefaultSocketPath = filepath.Join(confdir, socketName)
)

type Request struct {
	Method     string `json:"method"`
	Secret     Secret `json:"secret"`
	Id         string `json:"id"`
	SessionKey string `json:"session-key"`
}

type Response struct {
	Secret   Secret `json:"secret"`
	Metadata string `json:"metadata"`
	Status   string `json:"status"`
}

type Secret struct {
	Secret         []byte
	Add            time.Time
	Ttl            time.Duration
	MaxGetTimes    int
	Metadata       string
	uniqueIdentity int64
}

func ServerDecap(encap []byte) (shared []byte, err error) {
	conn, err := net.Dial("unix", DefaultSocketPath)
	if err != nil {
		return
	}

	defer conn.Close()

	encoder := json.NewEncoder(conn)
	decoder := json.NewDecoder(conn)

	var req Request
	var resp Response

	req.SessionKey = os.Getenv("STERN_SESSION_KEY")
	req.Method = "decap"
	req.Secret.Secret = encap

	if err := encoder.Encode(req); err != nil {
		panic(err)
	}

	if err := decoder.Decode(&resp); err != nil {
		panic(err)
	}

	if len(resp.Secret.Secret) == 0 {
		return nil, errors.New("secret not found")
	}
	shared = resp.Secret.Secret
	return
}
