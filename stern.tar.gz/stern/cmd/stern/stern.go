package main

import (
	"bufio"
	"bytes"
	"compress/gzip"
	"crypto/cipher"
	"crypto/sha3"
	"encoding/base64"
	"flag"
	"hash"
	"io"
	"log"
	"os"
	"path/filepath"
	"stern"

	"golang.org/x/crypto/chacha20poly1305"
	"golang.org/x/crypto/hkdf"
)

var (
	masterKeyPath string
	socketPath    string
	confdir       string
)

func main() {
	log.SetFlags(0)

	var (
		keyPath           string
		outputFilename    string
		inputFilename     string
		decryptFlag       bool
		encryptFlag       bool
		wfnameFlag        bool
		nonMaster         bool
		forceFlag         bool
		lsFlag            bool
		shortFilenameFlag bool
		safe              bool
		maskHeaderFlag    bool
	)

	flag.StringVar(&keyPath, "key", "", "key")
	flag.BoolVar(&encryptFlag, "e", false, "encrypt")
	flag.BoolVar(&wfnameFlag, "wfname", false, "fname from metadata")
	flag.BoolVar(&shortFilenameFlag, "short", false, "short filename")
	flag.BoolVar(&maskHeaderFlag, "mask", false, "mask header")
	flag.BoolVar(&maskHeaderFlag, "m", false, "mask header")
	flag.BoolVar(&decryptFlag, "d", false, "decrypt")
	flag.BoolVar(&forceFlag, "f", false, "force overwrite")
	flag.BoolVar(&safe, "safe", false, "safe mode")
	flag.BoolVar(&safe, "s", false, "safe mode")
	flag.BoolVar(&lsFlag, "ls", false, "view encrypted filenames")
	flag.StringVar(&outputFilename, "o", "", "output filename")
	flag.Parse()

	args := flag.Args()

	if encryptFlag == decryptFlag && !lsFlag {
		log.Fatalln("provide -e or -d flag")
	}

	if len(args) > 1 && !lsFlag {
		log.Fatalln("provide one filename")
	}

	homedir, err := os.UserHomeDir()
	if err != nil {
		panic(err)
	}

	confdir = filepath.Join(
		homedir,
		"/.config/stern/")

	masterKeyPath = filepath.Join(confdir, "master.key")

	if keyPath != "" {
		nonMaster = true
	} else {
		keyPath = masterKeyPath
	}

	if lsFlag {
		keyReader, err := os.Open(keyPath)
		if err != nil {
			panic(err)
		}
		defer keyReader.Close()
		for _, fname := range flag.Args() {
			f, err := os.Open(fname)
			if err != nil {
				panic(err)
			}

			d := stern.NewDecryptorGeneric(func(encap []byte) (shared []byte, err error) {
				if nonMaster {
					return defaultShared(encap, keyReader), nil
				}

				shared, err = stern.ServerDecap(encap)
				if err != nil {
					return defaultShared(encap, keyReader), nil
				}
				return shared, nil
			},
				nil,
				f,
			)
			log.Printf("%s -> %s\n", fname, string(d.GetMetadata()))
			f.Close()
		}
		return

	}
	var in io.Reader
	var out io.Writer

	if len(args) == 1 {
		inputFilename = args[0]
		f, err := os.Open(inputFilename)
		if err != nil {
			panic(err)
		}

		defer f.Close()
		in = f
	} else {
		in = os.Stdin
	}

	if (outputFilename == "" || outputFilename == "-") && !wfnameFlag {
		out = os.Stdout
	}

	if safe && (out == os.Stdout || outputFilename == "/dev/null") {
		log.Fatal("flag --safe must be used with output file only")
	}

	switch {
	case encryptFlag:
		keyReader, err := os.Open(keyPath)
		if err != nil {
			panic(err)
		}
		defer keyReader.Close()
		pub := stern.ParsePubKey(keyReader)
		e := stern.NewEncryptor(pub, in)
		if maskHeaderFlag {
			e.WithMaskedHeader()
		}
		if wfnameFlag {
			if outputFilename != "" {
				log.Fatal("output filename already provided")
			}
			if inputFilename != "-" && inputFilename != "" {
				filename := filepath.Base(inputFilename)
				e.WithMetadata([]byte(filename))
				keyReader, err := os.Open(keyPath)
				if err != nil {
					panic(err)
				}
				defer keyReader.Close()
				subkey := stern.ParseSubKey(keyReader)
				if shortFilenameFlag {
					outputFilename = getShortFilename(subkey, filename)
				} else {
					outputFilename = encryptFilename(subkey, filename)
				}

				if !forceFlag {
					_, err = os.Stat(outputFilename)
					if err == nil {
						log.Fatalln("file already exists, use -f flag to overwrite")
					}
				}
			} else {
				log.Fatal("stdin in use, filename not exists")
			}
		}

		if out != os.Stdout {
			if safe {
				if err := stern.SafeCopyToFile(outputFilename, e); err != nil {
					panic(err)
				}
			} else {
				f, err := os.Create(outputFilename)
				if err != nil {
					panic(err)
				}
				defer f.Close()
				out = f
			}
		}

		if _, err := io.Copy(out, e); err != nil {
			panic(err)
		}
	case decryptFlag:
		keyReader, err := os.Open(keyPath)
		if err != nil {
			panic(err)
		}
		defer keyReader.Close()

		d := stern.NewDecryptorGeneric(func(encap []byte) (shared []byte, err error) {
			if nonMaster {
				return defaultShared(encap, keyReader), nil
			}

			shared, err = stern.ServerDecap(encap)
			if err != nil {
				return defaultShared(encap, keyReader), nil
			}
			return shared, nil
		},
			nil,
			in,
		)

		if out != os.Stdout || (wfnameFlag && outputFilename == "") {
			if wfnameFlag {
				metadata := d.GetMetadata()
				if !bytes.Equal(metadata, stern.DefaultMetadata) && len(metadata) < 255 {
					outputFilename = string(metadata)
				} else {
					log.Fatalf("metadata invalid for filename: %s", string(metadata))
				}
			}

			if !forceFlag && outputFilename != "/dev/null" {
				_, err = os.Stat(outputFilename)
				if err == nil {
					log.Fatalln("file already exists, use -f flag to overwrite")
				}
			}

			if safe {
				if err := stern.SafeCopyToFile(outputFilename, d); err != nil {
					panic(err)
				}
			} else {

				f, err := os.Create(outputFilename)
				if err != nil {
					panic(err)
				}
				defer f.Close()
				out = f
			}
		}
		if _, err := io.Copy(out, d); err != nil {
			panic(err)
		}
	}
}

func defaultShared(encap []byte, keyReader io.Reader) []byte {
	sec := stern.ParseSecKey(
		bufio.NewReader(keyReader))
	return sec.Decap(encap)

}

func getShortFilename(subkey []byte, filename string) string {
	hk := hkdf.New(
		func() hash.Hash { return sha3.New512() },
		subkey,
		[]byte(filename),
		[]byte("stern-short-filename-generation"),
	)

	shortFilename := make([]byte, 12)
	io.ReadFull(hk, shortFilename)
	return "stern_s_" + base64.RawURLEncoding.EncodeToString(shortFilename)
}

func prepareAEAD(subkey []byte, filename string) cipher.AEAD {
	hk := hkdf.New(
		func() hash.Hash { return sha3.New512() },
		subkey,
		[]byte(filename),
		[]byte("stern-filename-encryption"),
	)

	key := make([]byte, chacha20poly1305.KeySize)
	_, err := io.ReadFull(hk, key)
	if err != nil {
		panic(err)
	}

	aead, err := chacha20poly1305.New(key)
	if err != nil {
		panic(err)
	}
	return aead
}

func compressFilename(filename string) []byte {
	UncompressedFlag := []byte{0x00}
	CompressedFlag := []byte{0x01}
	buf := &bytes.Buffer{}
	buf.Write(CompressedFlag)
	gz, err := gzip.NewWriterLevel(buf, 9)
	if err != nil {
		panic(err)
	}

	_, err = gz.Write([]byte(filename))
	if err != nil {
		panic(err)
	}
	gz.Close()

	if buf.Len() >= len([]byte(filename))+1 {
		buf.Reset()
		buf.Write(UncompressedFlag)
		buf.WriteString(filename)
	}
	return buf.Bytes()
}

func encryptFilename(subkey []byte, filename string) string {
	aead := prepareAEAD(subkey, filename)
	ext := filepath.Ext(filename)
	for {
		compressed := compressFilename(filename)
		filenameEnc := "stern_" + base64.RawURLEncoding.EncodeToString(aead.Seal(
			nil,
			make([]byte, aead.NonceSize()),
			compressed,
			[]byte("stern-encrypted-filename")))

		if len([]byte(filenameEnc)) >= 255 {
			filename = filename[:int(float64(len(filename))/1.1)] + "__." + ext
			continue
		}
		return string(filenameEnc)
	}
}
