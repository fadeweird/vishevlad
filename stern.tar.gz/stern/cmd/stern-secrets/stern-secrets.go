package main

import (
	"crypto/sha3"
	"encoding/json"
	"flag"
	"fmt"
	"log"
	"net"
	"os"
	"os/exec"
	"os/signal"
	"path/filepath"
	"stern"
	"syscall"
	"time"
	"unsafe"

	"golang.org/x/sys/unix"
)

const socketName = "stern-secrets-server.socket"

type Request struct {
	Method     string `json:"method"`
	Secret     Secret `json:"secret"`
	Id         string `json:"id"`
	SessionKey string `json:"session-key"`
}

type Response struct {
	Secret   Secret `json:"secret"`
	Metadata string `json:"metadata"`
	Status   string `json:"status"`
}

type Secret struct {
	Secret         []byte
	Add            time.Time
	Ttl            time.Duration
	MaxGetTimes    int
	Metadata       string
	uniqueIdentity int64
}

var SecKey *stern.SecKey
var globalTimer = time.NewTimer(time.Hour * 24)

func main() {
	err := unix.Mlockall(syscall.MCL_CURRENT | syscall.MCL_FUTURE)
	if err != nil {
		panic(err)
	}

	var (
		id, secret           string
		set, get, del, decap bool
		runServer            bool
		noTimeout            bool
		withSecretKey        bool
		withSessionKey       bool
		ttl                  time.Duration
		timeout              time.Duration
	)

	flag.BoolVar(&runServer, "run-server", false, "")
	flag.BoolVar(&withSecretKey, "with-secret-key", false, "")
	flag.BoolVar(&withSessionKey, "with-session-key", false, "")
	flag.BoolVar(&set, "set", false, "")
	flag.BoolVar(&noTimeout, "no-timeout", false, "")
	flag.BoolVar(&get, "get", false, "")
	flag.StringVar(&id, "id", "", "")
	flag.StringVar(&secret, "secret", "", "")
	flag.StringVar(&secret, "s", "", "")
	flag.DurationVar(&timeout, "timeout", time.Duration(0), "timeout for server (24 hours by default)")
	flag.DurationVar(&ttl, "ttl", time.Duration(0), "")
	flag.Parse()

	if timeout != 0 && noTimeout {
		log.Fatal("conflict flags: --timeout and --no-timeout")
	}

	if timeout != 0 {
		globalTimer = time.NewTimer(timeout)
	}

	if noTimeout {
		globalTimer.Stop()
	}

	if runServer && (get || set || decap || del ||
		id != "" || secret != "") {
		panic("--run-server excludes other flags except --with-session-key and --timeout")
	}

	homedir, err := os.UserHomeDir()
	if err != nil {
		panic(err)
	}

	socketPath := filepath.Join(homedir, ".config/stern", socketName)
	var sessionKey string

	if runServer {
		if withSecretKey {
			cmd := exec.Command(
				"stern-keygen",
				"-d",
				filepath.Join(homedir, "/.config/stern/master.key"))
			keyRaw, err := cmd.Output()
			if err != nil {
				panic(err)
			}

			SecKey = stern.NewSecKey(keyRaw)
		}

		if withSessionKey {
			sessionKey = createSessionKey()
			fmt.Printf("Please paste in your session:\nread -s STERN_SESSION_KEY\n\nand insert:\n%s\n\n", sessionKey)
			time.AfterFunc(time.Second*30, func() {
				fmt.Println("\033c")
				log.Printf("Server running: %s", socketPath)
			})
			go func() {
				fmt.Print("\nthen press ENTER >>>")
				fmt.Scanln()
				fmt.Println("\033c")
				log.Printf("Server running: %s", socketPath)
			}()
		}

		RunServer(socketPath, sessionKey)
		os.Exit(0)
	}

	if id == "" {
		panic("provide id")
	}

	if set == get {
		panic("provide -get or -set")
	}

	conn, err := net.Dial("unix", socketPath)
	if err != nil {
		log.Fatal(err)
	}
	defer conn.Close()

	encoder := json.NewEncoder(conn)
	decoder := json.NewDecoder(conn)

	var req Request
	var resp Response

	if get {
		req.SessionKey = os.Getenv("STERN_SESSION_KEY")
		req.Method = "get"
		req.Id = id
	} else if set {
		if secret == "" {
			panic("provide secret")
		}

		req.SessionKey = os.Getenv("STERN_SESSION_KEY")
		req.Method = "set"
		req.Id = id
		req.Secret = Secret{
			Secret:   []byte(secret),
			Ttl:      ttl,
			Metadata: ""}
	}

	if err := encoder.Encode(req); err != nil {
		log.Fatal(err)
	}

	if err := decoder.Decode(&resp); err != nil {
		log.Fatal(err)
	}
	log.SetFlags(0)
	log.Println("Got:")
	fmt.Println(string(resp.Secret.Secret))
	log.Println("metadata:", resp.Secret.Metadata)
	log.Println("status:", resp.Status)
}

func RunServer(socketPath, sessionKey string) {
	secrets := make(map[string]Secret, 10)
	Counter := int64(0)

	os.Remove(socketPath)
	listener, err := net.Listen("unix", socketPath)
	if err != nil {
		log.Fatalf("net.Listen: %v", err)
	}

	defer listener.Close()
	defer os.Remove(socketPath)
	if err := os.Chmod(socketPath, 0770); err != nil {
		log.Printf("os.Chmod: %v", err)
	}
	if err := os.Chown(socketPath, os.Getuid(), os.Getgid()); err != nil {
		log.Printf("os.Chown: %v", err)
	}

	log.Printf("Server running: %s", socketPath)

	sigChan := make(chan os.Signal, 1)
	signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM)
	go func() {
		select {
		case <-sigChan:
		case <-globalTimer.C:
		}
		log.Println("Exiting")
		listener.Close()
		os.Remove(socketPath)
		os.Exit(0)
	}()

	var (
		req     Request
		cred    unix.Ucred
		encoder *json.Encoder
		decoder *json.Decoder
		resp    = Response{Status: "success"}
	)

	for {
		conn, err := listener.Accept()
		if err != nil {
			if ne, ok := err.(*net.OpError); ok && ne.Err.Error() == "use of closed network connection" {
				break
			}
			log.Printf("Error: %v", err)
			continue
		}

		func() {
			defer conn.Close()
			log.Printf("Connected: %s\n", conn.RemoteAddr().String())

			uconn, ok := conn.(*net.UnixConn)
			if !ok {
				log.Println("Not Unix conn")
				return
			}

			f, err := uconn.File()
			if err != nil {
				log.Printf("File error: %v\n", err)
				return
			}
			defer f.Close()

			fd := int(f.Fd())

			var credlen uint32 = uint32(unsafe.Sizeof(cred))
			_, _, errno := syscall.Syscall6(
				syscall.SYS_GETSOCKOPT,
				uintptr(fd),
				syscall.SOL_SOCKET,
				unix.SO_PEERCRED,
				uintptr(unsafe.Pointer(&cred)),
				uintptr(unsafe.Pointer(&credlen)),
				0,
			)

			if errno != 0 {
				log.Println(unix.Ucred{}, errno)
			} else {
				log.Printf("PID: %d UID: %d GID: %d\n", cred.Pid, cred.Uid, cred.Gid)
			}

			decoder = json.NewDecoder(conn)
			encoder = json.NewEncoder(conn)

			if err = decoder.Decode(&req); err != nil {
				if err != nil {
					log.Printf("Error: %v %s\n\n", err, conn.RemoteAddr())
					return
				}
			}

			if sessionKey != "" && req.SessionKey != sessionKey {
				resp.Status = fmt.Sprintf("error: invalid session key = %s", req.SessionKey)
			} else {
				switch req.Method {
				case "set":
					log.Printf("Trying to set by id %s\n", req.Id)
					Counter++
					req.Secret.uniqueIdentity = Counter
					secrets[req.Id] = req.Secret
					if req.Secret.Ttl != time.Duration(0) {
						time.AfterFunc(req.Secret.Ttl, func() {
							if req.Secret.uniqueIdentity == secrets[req.Id].uniqueIdentity {
								delete(secrets, req.Id)
							}
						})
					}
				case "get":
					log.Printf("Trying to get by id %s\n", req.Id)
					var ok bool
					resp.Secret, ok = secrets[req.Id]
					if !ok {
						resp.Status = "error: secret not found"
					}
				case "decap":
					log.Println("Trying to decap: loading encapsulated")
					encap := req.Secret.Secret
					shared := SecKey.Decap(encap)
					resp.Secret.Secret = shared
				case "context_hash":
					allContext := req.Secret.Secret
					allContext = append(allContext, SecKey.PubKey().Bytes()...)
					allContext = append(allContext, SecKey.Bytes()[:24]...)

					allContext = append(allContext, SecKey.SubKey()...)
					h := sha3.Sum512(allContext)
					contextHash := h[:]
					resp.Secret.Secret = contextHash
				default:
					resp.Status = "error: method invalid"
				}
			}

			if err = encoder.Encode(resp); err != nil {
				panic(err)
			}
			log.Println("Success", req.Id)
			log.Println()
		}()
	}
}
