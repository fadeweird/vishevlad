package main

import (
	"crypto/rand"
	"encoding/binary"
	"io"
	"strings"
)

var list = strings.Split(`0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_-`, "")

func createSessionKey() (key string) {
	for i := 0; i < 11; i++ {
		key += randomChar(list)
	}
	return key
}

func randomChar(w []string) string {
	return w[getInt()%len(w)]
}

func getInt() int {
	b := make([]byte, 2)
	if _, err := io.ReadFull(rand.Reader, b); err != nil {
		panic(err)
	}

	return int(binary.BigEndian.Uint16(b))
}
